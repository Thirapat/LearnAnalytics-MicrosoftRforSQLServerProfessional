/* 
R for SQL Server Professionals Lab (Student).sql

Created by: Buck Woody, Microsoft
Last Updated: 01/27/2017
Purpose: Used to show how R and SQL Server can work together - This is the Student's Workbook.
Requires:
1. SQL Server 2016 (or higher) with all services installed, and R Services for SQL Server configured for use: https://msdn.microsoft.com/en-us/library/mt696069.aspx 
2. Download and Attach the AdventureWorks2012 Sample Database: https://msftdbprodsamples.codeplex.com/downloads/get/165399 
Resources:

*/

USE AdventureWorks2012;
GO

/* Show the top 10 products by sales */

AdventureWorks2012.Sales.SalesOrderDetail
Production.Product

/* Who bought those products? */
Person.BusinessEntityContact 
Person.Person 
Sales.Customer
Sales.SalesOrderHeader
Sales.SalesOrderDetail

/* Show the average price of all products sold, by Purchaser's state */
Sales.SalesOrderDetail
Production.Product

/* Which State/Province buys more products, Washington or England? */
Person.Address 
Person.StateProvince
Sales.SalesOrderHeader 
Sales.SalesOrderDetail

/* Question - should you check for billing area above, or shipping area? Why? */

/* Are those differences statistically significant?  Can you show how? */
